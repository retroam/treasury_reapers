#!/usr/bin/env bash
set -euo pipefail

INSTALL_DIR="${ARENA_INSTALL_DIR:-$HOME/.arena}"

echo "Installing arena-cli to $INSTALL_DIR ..."

# Check for uv
if ! command -v uv &>/dev/null; then
  echo "Error: uv is required. Install it: https://docs.astral.sh/uv/getting-started/installation/"
  exit 1
fi

# Create install directory and venv
mkdir -p "$INSTALL_DIR"
uv venv "$INSTALL_DIR/venv" --python ">=3.13" --quiet

# Install all wheels (order matters: core first, then sdk+harbor, then cli)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
uv pip install --python "$INSTALL_DIR/venv/bin/python" \
  "$SCRIPT_DIR"/arena_core-*.whl \
  "$SCRIPT_DIR"/harbor-*.whl \
  "$SCRIPT_DIR"/arena_sdk-*.whl \
  "$SCRIPT_DIR"/arena_cli-*.whl \
  --quiet

# Create symlink for arena command
mkdir -p "$INSTALL_DIR/bin"
ln -sf "$INSTALL_DIR/venv/bin/arena" "$INSTALL_DIR/bin/arena"

echo ""
echo "arena-cli installed successfully!"
echo ""
echo "Add to your PATH:"
echo "  export PATH=\"$INSTALL_DIR/bin:\$PATH\""
echo ""
echo "Then run:"
echo "  arena auth login"
echo "  arena doctor"
